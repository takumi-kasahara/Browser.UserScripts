// ==UserScript==
// @name      Rakuten Point Mall Gacha
// @namespace https://github.com/takumi-kasahara
// @version   1.0.0
// @match     https://pointmall.rakuten.co.jp/gacha
// @grant     none
// ==/UserScript==
"use strict";
(() => {
  // src/scripts/Rakuten Point Mall Gacha.user.ts
  window.addEventListener("load", () => {
    const e = document.querySelector(".normal_start");
    if (e instanceof HTMLElement) e.click();
  });
})();
